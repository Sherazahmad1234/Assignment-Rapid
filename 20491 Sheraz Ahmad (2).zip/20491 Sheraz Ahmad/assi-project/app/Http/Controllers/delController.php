<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Models\Employee;
class delController extends Controller
{
    
        public function index(){
            $row = DB::select('select * from employees');
            return view('stud_delete_view',['row$row'=>$row]);
            }
            public function destroy($id) {
            DB::delete('delete from employees where id = ?',[$id]);
            return redirect('/contactmessages')->with('success','data updated');
            }
        
}
