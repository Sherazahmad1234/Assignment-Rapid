<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Models\Employee;
class UpdateController extends Controller
{
    public function index() {
        $employees = DB::select('select * from employees');
        return view('contactmessages',['employees'=>$employees]);
     }
     public function show($id) {
        $employees = DB::select('select * from employees where id = ?',[$id]);
        return view('edit',['employees'=>$employees]);
     }
     public function edit(Request $request,$id) {
      
       $record = Employee::where('id', $id)->first();
       $record -> fullname = $request->input('fullname');
       $record -> email = $request->input('email');
       $record -> mobile = $request->input('mobile');
       $record -> message = $request->input('message');
       $record -> save();
        return redirect('/contactmessages')->with('success','data updated');
   
        
     }

}
