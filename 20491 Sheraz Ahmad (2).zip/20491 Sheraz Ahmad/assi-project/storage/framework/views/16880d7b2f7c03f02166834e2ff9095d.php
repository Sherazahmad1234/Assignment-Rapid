<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php $__env->startSection('title', 'Messages'); ?>
</head>
<body>
    

    <?php $__env->startSection('content'); ?>
    <div class="row">
        <div  class="col-md-12">
            <br>
            <h3 align="center">Employees Messages </h3>
            <br>
            <table class= "table table-bordered">
            <tr>
                <th>ID</th>  
                <th>Full Name</th>  
                <th>Email</th>
                <th>Mobile</th>
                <th>Message</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row['id']); ?></td>
                <td><?php echo e($row['fullname']); ?></td>
                <td><?php echo e($row['email']); ?></td>
                <td><?php echo e($row['mobile']); ?></td>
                <td><?php echo e($row['message']); ?></td>
               
                <td><a href = "edit/<?php echo e(($row ['id'])); ?>">Edit</a></td>
                <td><a href="delete/<?php echo e(($row ['id'])); ?>" onclick="return confirm('Are you want to sure you want to delete')">Delete</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\20491 Sheraz Ahmad\assi-project\resources\views/contactmessages.blade.php ENDPATH**/ ?>