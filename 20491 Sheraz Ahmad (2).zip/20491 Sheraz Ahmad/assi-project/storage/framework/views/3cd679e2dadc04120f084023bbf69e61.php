<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta fullname="viewport" content="width=device-width, initial-scale=1.0">
    <?php $__env->startSection('title', 'Edit'); ?>
</head>
<body>
    

    <?php $__env->startSection('content'); ?>
    <div class="row">
        <div  class="col-md-12">
            <br>
            <h3>Employees Messages Edit </h3>
            <br>
            <form action = "/edit/<?php echo $employees[0]->id; ?>" method = "post">
                <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
            
                <table>
                    <tr>
                    <td>Name</td>
                    <td>
                        <input type = 'text' name = 'fullname' 
                            value = '<?php echo$employees[0]->fullname; ?>'/>
                    </td>
                    <td>Email</td>
                    <td>
                        <input type = 'email' name = 'email' 
                            value = '<?php echo$employees[0]->email; ?>'/>
                    </td>
                    <td>Mobile</td>
                    <td>
                        <input type = 'phone' name = 'mobile' 
                            value = '<?php echo$employees[0]->mobile; ?>'/>
                    </td>
                    <td>Message</td>
                    <td>
                        <input type = 'text' name = 'message' 
                            value = '<?php echo$employees[0]->message; ?>'/>
                    </td>
                    </tr>
                    <tr>
                    <td colspan = '2'>
                        <input type = 'submit' onclick="return confirm('Are you want to sure you want to update')" value = "Update Record" />
                    </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\20491 Sheraz Ahmad\assi-project\resources\views/edit.blade.php ENDPATH**/ ?>