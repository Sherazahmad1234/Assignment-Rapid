<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UpdateController;
use App\Http\Controllers\delController;
Route::view('/', 'index');
// Route::view('/', 'welcome');
Route::get('services', function() {
    return View::make('services');
});
// Route::get('contactmessages', function() {
//     return View::make('contactmessages');
// });
Route::view('/about', 'about');


Route::get('contact', [UserController::class, 'contact']);
Route::post('contact', [UserController::class, 'savedata']);
Route::get('contactmessages', [UserController::class, 'show']);


Route::get('edit', [UpdateController::class, 'index']);
Route::get('edit/{id}', [UpdateController::class, 'show']);
Route::post('edit/{id}', [UpdateController::class, 'edit']);
Route::get('delete-records}', [delController::class, 'index']);
Route::get('delete/{id}', [delController::class, 'destroy']);

// Route::get('edit', 'UserController@edit');
// // Route::post('message/edit/{id}', 'UserController@edit');

// Route::get('delete','UserController@index');
// // Route::post('delete/{id}','UserController@destroy');
// // Route::post('edit/{id}', [UserController::class, 'edit']);
// // Route::post('edit/{id}', [UserController::class, 'edit']);
// // Route::post('edit', 'UserController@update');
// // // Route::post('edit', 'UserController'); 
